for file in /Users/toghani/Desktop/projects/CCR_nterm/analysis/hmm_nonflowering/profiles/*.hmm; \
do hmmsearch --max --tblout `basename $file .hmm`_tbl.out --domtblout `basename $file .hmm`_domtbl.out -o `basename $file .hmm`.out $file /Users/toghani/Desktop/projects/CCR_nterm/analysis/hmm_nonflowering/Chia_ref_out.fasta; \
done